﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Shortest_Path
{
    public enum DirectionType
    {
        Directed,
        Undirected
    }
    internal class Graph : IEnumerable
    {
        internal Vertex[] vertices;
        PartiallyOrderedTree pot;

        public Graph(int[] nodes)
        {
            vertices = new Vertex[nodes.Length];
            pot = new PartiallyOrderedTree(this);
            for (int i = 0; i < vertices.Length; i++)
            {
                this.vertices[i] = new Vertex(nodes[i]);
                vertices[i].Index = i;
            }
        }

        public void AddEdge(int source, int destination, double cost, DirectionType direction)
        {
            // Add edge based on the direction type
            if (direction == DirectionType.Undirected)
            {
                // Add edge from source to destination
                vertices[source].AddEdge(destination + 1, cost); // AddEdge expects 1-based index
                                                                 // Add edge from destination to source
                vertices[destination].AddEdge(source + 1, cost); // AddEdge expects 1-based index
            }
            else
            {
                // Add edge from source to destination
                vertices[source].AddEdge(destination + 1, cost); // AddEdge expects 1-based index
            }
        }

            IEnumerator IEnumerable.GetEnumerator()
        {
            foreach (var vertex in vertices)
                yield return vertex;
        }
        public void Display()
        {
            foreach (var o in this)
                Console.WriteLine(o);

            pot.Display();

            Console.ReadLine();
        }
        public void FindShortestPath()
        {
            foreach (var sourceNode in vertices)
            {
                double[] distances = new double[vertices.Length];
                for (int i = 0; i < vertices.Length; i++)
                {
                    distances[i] = double.PositiveInfinity;
                }
                distances[sourceNode.Index] = 0;

                SortedDictionary<double, int> priorityQueue = new SortedDictionary<double, int>();
                priorityQueue.Add(0, sourceNode.Index);
                foreach (var vertex in vertices)
                {
                    priorityQueue.Add(distances[vertex.Index-1], vertex.Index);
                }

                while (priorityQueue.Count > 0)
                {
                    var minDistanceVertexIndex = priorityQueue.First().Value;
                    priorityQueue.Remove(priorityQueue.First().Key);

                    foreach (var edge in vertices[minDistanceVertexIndex - 1].Neighbors)
                    {
                        var neighborIndex = edge.Destination;
                        var alt = distances[minDistanceVertexIndex - 1] + edge.Cost;
                        if (alt < distances[neighborIndex - 1])
                        {
                            distances[neighborIndex - 1] = alt;
                            priorityQueue.Remove(distances[neighborIndex - 1]);
                            priorityQueue.Add(alt, neighborIndex);
                        }
                    }
                }

                for (int i = 0; i < distances.Length; i++)
                {
                    Console.WriteLine($"Shortest distance from node {sourceNode.Index} to node {i + 1}: {distances[i]}");
                }
            }
        }
    }
}
